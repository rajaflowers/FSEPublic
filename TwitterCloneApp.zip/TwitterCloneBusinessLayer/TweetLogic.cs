﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TwitterCloneDataAccess;

namespace TwitterCloneBusinessLayer
{
    public class TweetLogic
    {
        public void Signup(Person person)
        {
            using (FseProgramEntities entities = new FseProgramEntities())
            {
                entities.People.Add(person);
                entities.SaveChanges();
            }
            return;
        }

        public Person Signin(Person person)
        {
            using (FseProgramEntities entities = new FseProgramEntities())
            {
                return entities.People.Where(p=>p.User_ID == person.User_ID && p.Password== person.Password).FirstOrDefault();
            }
        }

        public Person GetHomeDetails(string UserId)
        {
            using (FseProgramEntities entities = new FseProgramEntities())
            {
                return entities.People.Where(p => p.User_ID == UserId).FirstOrDefault();
            }
        }

        public IList<Tweet> GetTweets(string UserId)
        {
            using (FseProgramEntities entities = new FseProgramEntities())
            {
                return entities.Tweets.Where(p => p.User_ID == UserId).ToList();
            }
        }

        public IList<Following> GetFollowings(string UserId)
        {
            using (FseProgramEntities entities = new FseProgramEntities())
            {
                return entities.Followings.Where(p => p.User_ID == UserId).ToList();
            }
        }

        public IList<Following> GetFollowers(string UserId)
        {
            using (FseProgramEntities entities = new FseProgramEntities())
            {
                return entities.Followings.Where(p => p.Following_ID == UserId).ToList();
            }
        }

        public void Tweet(Tweet tweet)
        {
            using (FseProgramEntities entities = new FseProgramEntities())
            {
                entities.Tweets.Add(tweet);
                entities.SaveChanges();
            }
            return;
        }

        public void Follow(Following follow)
        {
            using (FseProgramEntities entities = new FseProgramEntities())
            {
                entities.Followings.Add(follow);
                entities.SaveChanges();
            }
            return;
        }

        public void Unfollow(Following follow)
        {
            using (FseProgramEntities entities = new FseProgramEntities())
            {
                entities.Followings.Remove(follow);
                entities.SaveChanges();
            }
            return;
        }
    }
}
