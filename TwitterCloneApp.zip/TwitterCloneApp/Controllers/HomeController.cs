﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using TwitterCloneBusinessLayer;
using TwitterCloneDataAccess;

namespace TwitterCloneApp.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            Person person = (Person)(Session["UserData"]);
            TweetLogic tweetLogic = new TweetLogic();
            if (person != null)
            {
                tweetLogic.GetHomeDetails(person.User_ID);
                IList<Following> followers = tweetLogic.GetFollowers(person.User_ID);
                IList<Following> followings = tweetLogic.GetFollowings(person.User_ID);
                IList<Tweet> tweets = tweetLogic.GetTweets(person.User_ID);

                List<TwitterCloneApp.Models.Tweet> lst = new List<TwitterCloneApp.Models.Tweet>();
                foreach (var item in tweets)
                {
                    lst.Add(new TwitterCloneApp.Models.Tweet()
                    {
                        Message = item.Message,
                        User_ID = item.User_ID,
                        Created = item.Created,
                        Tweet_ID = item.Tweet_ID
                    });
                }

                ViewBag.tweets = lst;
                ViewBag.tweetsCount = tweets.Count();
                ViewBag.followingCount = followings.Count();
                ViewBag.followersCount = followers.Count();
            }
            else
            {
                return RedirectToAction("Signin", "SignUp");
            }
            return View();
        }

        public ActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Create(FormCollection collection)
        {
            Person person = (Person)(Session["UserData"]);
            TweetLogic tweetLogic = new TweetLogic();
            tweetLogic.Tweet(new TwitterCloneDataAccess.Tweet()
            {
                User_ID = person.User_ID,
                Created = DateTime.Now,
                Message = Convert.ToString(collection["Message"])
            }
            );
            return View();
        }

        public ActionResult UpdateTweet(string Message)
        {
            Person person = (Person)(Session["UserData"]);
            TweetLogic tweetLogic = new TweetLogic();
            tweetLogic.Tweet(new TwitterCloneDataAccess.Tweet()
            {
                User_ID = person.User_ID,
                Created = DateTime.Now,
                Message = Convert.ToString(Message)
            }
            );
            return null;
        }

        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }
    }
}