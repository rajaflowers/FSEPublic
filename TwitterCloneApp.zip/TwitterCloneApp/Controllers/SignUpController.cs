﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using TwitterCloneApp.Models;
using TwitterCloneBusinessLayer;

namespace TwitterCloneApp.Controllers
{
    public class SignUpController : Controller
    {
        // GET: SignUp
        public ActionResult Index()
        {
            return RedirectToAction("Index", "Home");
        }

        // GET: SignUp/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: SignUp/Create
        [HttpPost]
        public ActionResult Create(FormCollection collection)
        {
            try
            {
                // TODO: Add insert logic here
                TweetLogic tweetLogic = new TweetLogic();
                tweetLogic.Signup(new TwitterCloneDataAccess.Person()
                {
                    User_ID = collection["User_ID"],
                    Active = true,
                    Email = collection["Email"],
                    FullName = collection["FullName"],
                    Joined = DateTime.Now,
                    Password = collection["Password"]
                }
                );
                return RedirectToAction("SignIn");
            }
            catch (Exception ex)
            {
                return View();
            }
        }

        public ActionResult SignIn()
        {
            return View();
        }

        [HttpPost]
        public ActionResult SignIn(FormCollection collection)
        {
            TweetLogic tweetLogic = new TweetLogic();
            var result = tweetLogic.Signin(
                new TwitterCloneDataAccess.Person()
                {
                    User_ID = collection["User_ID"],
                    Password = collection["Password"]
                }
                );
            if (result != null && result.User_ID != null)
            {
                Session["UserData"] = result;
                return RedirectToAction("Index", "Home");
            }

            return View();
        }

        // GET: SignUp/Details/5
        public ActionResult Details(int id)
        {
            return View();
        }

        // GET: SignUp/Edit/5
        public ActionResult Edit(int id)
        {
            return View();
        }

        // POST: SignUp/Edit/5
        [HttpPost]
        public ActionResult Edit(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add update logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: SignUp/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: SignUp/Delete/5
        [HttpPost]
        public ActionResult Delete(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add delete logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }
    }
}
