﻿using System.ComponentModel.DataAnnotations;

namespace TwitterCloneApp.Models
{
    public class Tweet
    {   [Display(Name = "ID")]
        public int Tweet_ID { get; set; }
        [Display(Name = "User")]
        public string User_ID { get; set; }
        [Display(Name = "Tweet")]
        public string Message { get; set; }
        [Display(Name = "Time")]
        public System.DateTime Created { get; set; }
    }
}