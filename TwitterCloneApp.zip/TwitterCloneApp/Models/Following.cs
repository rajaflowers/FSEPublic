﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TwitterCloneApp.Models
{
    public class Following
    {
        public string User_ID { get; set; }
        public string Following_ID { get; set; }
    }
}