﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MyWebApp.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult About()
        {
            ServiceReference1.Service1Client service = new ServiceReference1.Service1Client();
            ViewBag.Message = service.SayHello("Raja");
            return View();
        }

        public ActionResult Contact()
        {
            ServiceReference1.Service1Client service = new ServiceReference1.Service1Client();
            ViewBag.Message = service.TodayProgram("Raja");
            return View();
        }

        public ActionResult Add()
        {
            ServiceReference1.Service1Client service = new ServiceReference1.Service1Client();
            ViewBag.Message = service.Add(10,20);
            return View();
        }

        public ActionResult Subtract()
        {
            ServiceReference1.Service1Client service = new ServiceReference1.Service1Client();
            ViewBag.Message = service.Subtract(20,10);
            return View();
        }
    }
}